fx_version 'adamant'
games { 'gta5' }

description 'Mosleys Props for https://www.gta5-mods.com/maps/mosley-s-auto-shop-interior-sp-fivem'
made_by 'Q for Project V RP'
discord 'https://pvrp.pw/discord'


client_scripts {
	'props.lua',
}