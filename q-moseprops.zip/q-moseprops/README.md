# What is this?
Made by QuantumSGT aka Q for Project V RP (https://pvrp.pw/discord) to create more usable areas from 'Mosleys' by https://www.gta5-mods.com/maps/mosley-s-auto-shop-interior-sp-fivem

# Including
- Staff Parking/Material Vehicle Parking
- Customer Waiting/Parking
- 2 bays
- An assortedment of items to 'give life'
- Radio prop that you can dial in jim-djbooth or g-musicmanager
- All created using basegame props using QBCore

# INSTALL
Extract file into resources then ensure in your server.cfg. We have this file in our [map] folder alongside the Mosley's map folder.

# LONG LIVE MOSMOS
Please come on by and see our efforts over at the Discord link above! 5 weeks into Lua and learning and we're loving it!!

